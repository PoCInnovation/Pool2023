import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

def get_dataset(batch_size = 100, noise = 0.1):
    x = np.linspace(0, 100, batch_size)
    f = lambda x: (2 / 3) * x
    noise = np.random.normal(0, noise, x.shape)
    y = f(x) + noise
    
    return x, y

def display_dataset(x, y):
    fig = plt.figure()
    ax = plt.axes()

    ax.scatter(x, y)
    ax.grid()
    ax.set_title('Representation of the dataset')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    plt.show()

def display_function(x, f):
    fig = plt.figure()
    ax = plt.axes()

    ax.plot(x, f(x))
    ax.grid()
    ax.set_title('Representation of the ' + f.__name__ + ' function')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    plt.show()
