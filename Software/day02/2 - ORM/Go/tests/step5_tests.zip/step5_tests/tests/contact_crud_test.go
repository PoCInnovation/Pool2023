package tests

import (
	"SoftwareGoDay2/ent"
	"context"
	"strings"
	"testing"
)

func TestCreateContact(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	contacts := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	expected := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	var artistCreate []*ent.Artist

	ctx := context.Background()

	for _, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}
	for i, c := range contacts {
		newC, err := db.CreateContact(ctx, artistCreate[i].ID, c.Email, c.Phone)
		if err != nil {
			t.Errorf("Contact create failed: '%v'", err)
		}
		if newC.Email != expected[i].Email {
			t.Errorf("wrong create email for contact '%v': got '%v', expected: '%v'", c.Email, newC.Email, expected[i].Email)
		}

		if newC.Phone != expected[i].Phone {
			t.Errorf("wrong create Phone for contact '%v': got '%v', expected: '%v'", c.Email, newC.Phone, expected[i].Phone)
		}
	}
	cleanUpDatabase(t)
}

func TestCreateContactError(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
	}
	var artistCreate []*ent.Artist
	ctx := context.Background()
	for _, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}

	db.CreateContact(ctx, artistCreate[0].ID, "Florida@travel.com_test", "0678546140")
	_, err := db.CreateContact(ctx, artistCreate[0].ID, "Florida@travel2.com_test", "06785461402")

	if !strings.Contains(err.Error(), "contacts_artist_contact_key") {
		t.Errorf("Failed, you didn't setup unique contraint on artist id. error: %x", err)
	}
	cleanUpDatabase(t)
}

func TestUpdateContact(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	contacts := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "a"},
		{Email: "a_test", Phone: "0780156782"},
	}
	Updates := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	expected := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	var artistCreate []*ent.Artist
	var contactCreate []*ent.Contact

	ctx := context.Background()

	for _, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}
	for i, c := range contacts {
		newC, err := db.CreateContact(ctx, artistCreate[i].ID, c.Email, c.Phone)
		contactCreate = append(contactCreate, newC)
		if err != nil {
			t.Errorf("Contact create failed: '%v'", err)
		}
	}

	for i, c := range Updates {
		upC, err := db.UpdateContact(ctx, &ent.Contact{ID: contactCreate[i].ID, Email: c.Email, Phone: c.Phone})
		if err != nil {
			t.Errorf("Contact update failed: '%v'", err)
		}
		if upC.Email != expected[i].Email {
			t.Errorf("wrong update email for contact '%v': got '%v', expected: '%v'", c.Email, upC.Email, expected[i].Email)
		}
		if upC.Phone != expected[i].Phone {
			t.Errorf("wrong update Phone for contact '%v': got '%v', expected: '%v'", c.Email, upC.Phone, expected[i].Phone)
		}
	}
	cleanUpDatabase(t)
}
