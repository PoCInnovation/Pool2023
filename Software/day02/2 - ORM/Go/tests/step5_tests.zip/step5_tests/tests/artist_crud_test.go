package tests

import (
	"SoftwareGoDay2/ent"
	"context"
	"strings"
	"testing"
)

func cleanUpDatabase(t *testing.T) {
	ctx := context.Background()

	artists, err := db.GetArtists(ctx)
	if err != nil {
		t.Errorf("CleanUp Database failed: %v", err)
	}
	contacts, err := db.Client.Contact.Query().All(ctx)
	if err != nil {
		t.Errorf("CleanUp Database failed: %v", err)
	}
	for _, c := range contacts {
		if strings.Contains(c.Email, "_test") {
			_, err = db.DeleteContact(ctx, c.ID)
			if err != nil {
				t.Errorf("Delete contact Failed: %v", err)
			}
		}
	}
	for _, a := range artists {
		if strings.Contains(a.Name, "_test") {
			_, err = db.DeleteArtist(ctx, a.ID)
			if err != nil {
				t.Errorf("Delete user Failed: %v", err)
			}
		}
	}
}

func TestCreateArtist(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	expected := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}

	ctx := context.Background()

	for i, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		if u.Name != expected[i].Name {
			t.Errorf("wrong create name for artist %v: got :%v , expected: %v", a.Name, u.Name, expected[i].Name)
		}

		if u.Nationality != expected[i].Nationality {
			t.Errorf("wrong create nationality for artist %v: got :%v , expected: %v", a.Name, u.Nationality, expected[i].Nationality)
		}
	}
	cleanUpDatabase(t)
}

func TestGetArtist(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: ""},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()

	for _, a := range artists {
		_, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}

	aList, err := db.GetArtists(ctx)
	if err != nil {
		t.Errorf("GetArtists failed: %v", err)
	}
	nb := 0
	for _, a := range aList {
		if strings.Contains(a.Name, "_test") {
			nb += 1
		}
	}
	if nb != len(artists) {
		t.Errorf("GetArtists fail. Should have lenght %v but got %v", len(artists), nb)
	}
	cleanUpDatabase(t)
}

func TestGetArtistById(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "fr"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()

	for _, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		uGet, _ := db.GetArtistByID(ctx, u.ID)

		if uGet.ID != u.ID {
			t.Errorf("Get artists by id fail: %v %v", uGet, u)
		}
	}
	cleanUpDatabase(t)
}

func TestUpdateArtist(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: ""},
		{Name: "Charles Aznavour_test", Nationality: "am"},
		{Name: "France Galle (wrong)_test", Nationality: "fr"},
	}
	update := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
		{Name: "France Gall_test", Nationality: "fr"},
	}
	expected := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
		{Name: "France Gall_test", Nationality: "fr"},
	}

	ctx := context.Background()

	for i, a := range artists {
		a, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}

		u, err := db.UpdateArtist(ctx, &ent.Artist{ID: a.ID, Name: update[i].Name, Nationality: update[i].Nationality})
		if err != nil {
			t.Errorf("artist update failed: %v", err)
		}

		if a.ID.String() != u.ID.String() {
			t.Errorf("artist update changed the ID: %v", err)
		}

		if u.Name != expected[i].Name {
			t.Errorf("wrong update name for artist %v: got :%v , expected: %v", a.Name, u.Name, expected[i].Name)
		}

		if u.Nationality != expected[i].Nationality {
			t.Errorf("wrong update nationality for artist %v: got :%v , expected: %v", a.Name, u.Nationality, expected[i].Nationality)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteArtist(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "fr"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()

	for _, a := range artists {
		u, err := db.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		_, err = db.DeleteArtist(ctx, u.ID)
		if err != nil {
			t.Errorf("Delete artist fail: %v", err)
		}
		_, err = db.GetArtistByID(ctx, u.ID)
		if err == nil {
			t.Errorf("Delete artist failed. User '%v' still exist", u.ID)
		}
	}
	cleanUpDatabase(t)
}
