package tests

import (
	"SoftwareGoDay2/controller"
	"context"
	"errors"
	"testing"
)

func TestCreateArtist(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida", Nationality: ""},
		{Name: "Charles Aznavour", Nationality: ""},
	}

	c := controller.NewController(NewMockDatabase())
	ctx := context.Background()

	for _, a := range artists {
		_, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}
}

func TestCreateArtistError(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "", Nationality: "us"},
		{Name: "", Nationality: "fr"},
	}

	c := controller.NewController(NewMockDatabase())
	ctx := context.Background()

	for _, a := range artists {
		a, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if !errors.Is(err, controller.InvalidArtistName) {
			t.Errorf("artist create did not failed: %v", a)
		}
	}
}

func TestUpdateArtistError(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida", Nationality: ""},
		{Name: "Charles Aznavour", Nationality: "fr"},
		{Name: "France Galle (wrong)", Nationality: "fr"},
	}
	update := []struct {
		Name, Nationality string
	}{
		{Name: "", Nationality: "us"},
		{Name: "", Nationality: "am"},
		{Name: "France Gall", Nationality: ""},
	}
	expected := []struct {
		Name, Nationality string
	}{
		{Name: "Florida", Nationality: "us"},
		{Name: "Charles Aznavour", Nationality: "am"},
		{Name: "France Gall", Nationality: "fr"},
	}

	c := controller.NewController(NewMockDatabase())
	ctx := context.Background()

	for i, a := range artists {
		a, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}

		u, err := c.UpdateArtist(ctx, a.ID.String(), update[i].Name, update[i].Nationality)
		if err != nil {
			t.Errorf("artist update failed: %v", err)
		}

		if a.ID.String() != u.ID.String() {
			t.Errorf("artist update changed the ID: %v", err)
		}

		if u.Name != expected[i].Name {
			t.Errorf("wrong update name for artist %v: got :%v , expected: %v", a.Name, u.Name, expected[i].Name)
		}

		if u.Nationality != expected[i].Nationality {
			t.Errorf("wrong update nationality for artist %v: got :%v , expected: %v", a.Name, u.Nationality, expected[i].Nationality)
		}
	}
}
