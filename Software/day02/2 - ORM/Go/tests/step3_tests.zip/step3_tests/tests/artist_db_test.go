package tests

import (
	"SoftwareGoDay2/database"
	"log"
	"os"

	"github.com/joho/godotenv"
	"github.com/pkg/errors"
)

var db *database.Database

func init() {
	// Chargez votre environnement
	err := godotenv.Load("./../.env")
	if err != nil {
		log.Fatalf("%+v\n", errors.Wrap(err, "failed to load environment"))
	}
	dbURL := os.Getenv("DB_URL")
	if dbURL == "" {
		log.Fatalf("%+v\n", errors.New("ENV variable 'DB_URL' is not defined"))
	}

	db, err = database.NewDatabase(dbURL)
	if err != nil {
		log.Fatalf("Failed to initialize database: %+v\n", err)
	}
}