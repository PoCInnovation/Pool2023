package tests

import (
	"SoftwareGoDay2/controller"
	"context"
	"strings"
	"testing"
)

func TestCreateArtistController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	expected := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}

	ctx := context.Background()

	c := controller.NewController(db)

	for i, a := range artists {
		u, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		if u.Name != expected[i].Name {
			t.Errorf("wrong create name for artist %v: got :%v , expected: %v", a.Name, u.Name, expected[i].Name)
		}

		if u.Nationality != expected[i].Nationality {
			t.Errorf("wrong create nationality for artist %v: got :%v , expected: %v", a.Name, u.Nationality, expected[i].Nationality)
		}
	}
	cleanUpDatabase(t)
}

func TestCreateArtistErrorController(t *testing.T) {

	ctx := context.Background()
	c := controller.NewController(db)

	_, err := c.CreateArtist(ctx, "", "fr")
	if err == nil {
		t.Errorf("Creating artist with a empty name did not fail.")
	}
	if err.Error() != "artist name is invalid" {
		t.Errorf("Creating artist with a empty name's error should match 'artist name is invalid' but got '%v'.", err)
	}
}

func TestGetArtistController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: ""},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()
	c := controller.NewController(db)

	for _, a := range artists {
		_, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}

	aList, err := c.GetArtists(ctx)
	if err != nil {
		t.Errorf("GetArtists failed: %v", err)
	}
	nb := 0
	for _, a := range aList {
		if strings.Contains(a.Name, "_test") {
			nb += 1
		}
	}
	if nb != len(artists) {
		t.Errorf("GetArtists fail. Should have lenght %v but got %v", len(artists), nb)
	}
	cleanUpDatabase(t)
}

func TestGetArtistByIdController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "fr"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()
	c := controller.NewController(db)

	for _, a := range artists {
		u, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		uGet, _ := c.GetArtistByID(ctx, u.ID.String())

		if uGet.ID != u.ID {
			t.Errorf("Get artists by id fail: %v %v", uGet, u)
		}
	}
	cleanUpDatabase(t)
}

func TestGetArtistByIdErrorController(t *testing.T) {

	ctx := context.Background()
	c := controller.NewController(db)

	_, err := c.GetArtistByID(ctx, "bad_id")
	if err == nil {
		t.Errorf("Get artist with wrong id did not fail.")
	}
	if err.Error() != "artist id is invalid" {
		t.Errorf("Get artist with wrong id's error should match 'artist name is invalid' but got '%v'.", err)
	}
}

func TestUpdateArtistController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: ""},
		{Name: "Charles Aznavour_test", Nationality: "am"},
		{Name: "France Galle (wrong)_test", Nationality: "fr"},
	}
	update := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: ""},
		{Name: "", Nationality: "fr"},
	}
	expected := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
		{Name: "France Galle (wrong)_test", Nationality: "fr"},
	}

	ctx := context.Background()
	c := controller.NewController(db)

	for i, a := range artists {
		a, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}

		u, err := c.UpdateArtist(ctx, a.ID.String(), update[i].Name, update[i].Nationality)
		if err != nil {
			t.Errorf("artist update failed: %v", err)
		}

		if a.ID.String() != u.ID.String() {
			t.Errorf("artist update changed the ID: %v", err)
		}

		if u.Name != expected[i].Name {
			t.Errorf("wrong update name for artist %v: got :%v , expected: %v", a.Name, u.Name, expected[i].Name)
		}

		if u.Nationality != expected[i].Nationality {
			t.Errorf("wrong update nationality for artist %v: got :%v , expected: %v", a.Name, u.Nationality, expected[i].Nationality)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteArtistController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "fr"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	ctx := context.Background()
	c := controller.NewController(db)

	for _, a := range artists {
		u, err := c.CreateArtist(ctx, a.Name, a.Nationality)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
		_, err = c.DeleteArtist(ctx, u.ID.String())
		if err != nil {
			t.Errorf("Delete artist fail: %v", err)
		}
		_, err = c.GetArtistByID(ctx, u.ID.String())
		if err == nil {
			t.Errorf("Delete artist failed. User '%v' still exist", u.ID)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteArtistErrorController(t *testing.T) {

	ctx := context.Background()
	c := controller.NewController(db)

	_, err := c.DeleteArtist(ctx, "bad_id")
	if err == nil {
		t.Errorf("Delete artist with wrong id did not fail.")
	}
	if err.Error() != "artist id is invalid" {
		t.Errorf("Delete artist with wrong id's error should match 'artist name is invalid' but got '%v'.", err)
	}
}
