package tests

import (
	"SoftwareGoDay2/controller"
	"SoftwareGoDay2/ent"
	"context"
	"testing"
)

func TestCreateRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	expected := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)

	for i, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		if newRC.Name != expected[i].Name {
			t.Errorf("wrong create Name Record Company: got '%v', expected: '%v'", newRC.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestGetRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}
	RecordCompaniesList, err := ctr.GetRecordCompanies(ctx)
	if err != nil {
		t.Errorf("Get all record company failed: '%v'", err)
	}
	for i, rc := range RecordCompaniesList {
		if rc.ID.String() == recordCompanyCreate[i].ID.String() && rc.Name != recordCompanyCreate[i].Name {
			t.Errorf("Get all record company failed. %v", err)
		}
	}
	cleanUpDatabase(t)
}

func TestGetRecordCompanyByIdController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)

	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}
	for _, rc := range recordCompanyCreate {
		getRC, err := ctr.GetRecordCompanyByID(ctx, rc.ID.String())
		if err != nil {
			t.Errorf("Get Record Company by id failed: '%v'", err)
		}
		if rc.Name != getRC.Name {
			t.Errorf("Get record company by id failed for '%v'. Got '%v' but '%v' expected ", rc.Name, getRC.Name, rc.Name)
		}
	}
	cleanUpDatabase(t)
}

func TestRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "aa"},
	}
	update := []struct {
		Name string
	}{
		{Name: ""},
		{Name: "Abbey Road Studios_test"},
	}
	expected := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)

	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}

	for i, u := range update {
		recordCompanyCreate[i].Name = u.Name
		updateRC, err := ctr.UpdateRecordCompany(ctx, recordCompanyCreate[i].ID.String(), recordCompanyCreate[i].Name)
		if err != nil {
			t.Errorf("Record Company update failed: '%v'", err)
		}
		if updateRC.Name != expected[i].Name {
			t.Errorf("wrong update Name Record Company: got '%v', expected: '%v'", updateRC.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "aa"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}

	for _, u := range recordCompanyCreate {
		_, err := ctr.DeleteRecordCompany(ctx, u.ID.String())
		if err != nil {
			t.Errorf("Record Company delete failed: '%v'", err)
		}
		_, err = ctr.GetRecordCompanyByID(ctx, u.ID.String())
		if err == nil {
			t.Errorf("Record Company delete failed, '%v' still exits in database", u)
		}
	}
	cleanUpDatabase(t)
}

func TestAddArtistToRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)
	u1, _ := ctr.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := ctr.CreateArtist(ctx, "jb_test", "fr")

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		newRC, err = ctr.AddArtistToRecordCompany(ctx, newRC.ID.String(), u1.ID.String())
		if err != nil {
			t.Errorf("Add artist to record company failed: '%v'", err)
		}
		newRC, err = ctr.AddArtistToRecordCompany(ctx, newRC.ID.String(), u2.ID.String())
		if err != nil {
			t.Errorf("Add artist to record company failed: '%v'", err)
		}
		companyartists, _ := newRC.QueryArtists().All(ctx)
		if len(companyartists) != 2 {
			t.Errorf("Add artists to record company failed: Only have %v but 2 was expected", len(companyartists))
		}
	}
	cleanUpDatabase(t)
}

func TestRemoveArtistToRecordCompanyController(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)

	u1, _ := ctr.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := ctr.CreateArtist(ctx, "jb_test", "fr")
	var recordCompanyCreate *ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := ctr.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		newRC, _ = ctr.AddArtistToRecordCompany(ctx, newRC.ID.String(), u1.ID.String())
		newRC, _ = ctr.AddArtistToRecordCompany(ctx, newRC.ID.String(), u2.ID.String())
		recordCompanyCreate = newRC
	}
	ctr.RemoveArtistFromRecordCompany(ctx, recordCompanyCreate.ID.String(), u1.ID.String())
	companyartists, _ := recordCompanyCreate.QueryArtists().All(ctx)

	if len(companyartists) != 1 {
		t.Errorf("Remove artists from record company failed: Have %v artists but 1 was expected", len(companyartists))
	}
	ctr.RemoveArtistFromRecordCompany(ctx, recordCompanyCreate.ID.String(), u2.ID.String())
	companyartists, _ = recordCompanyCreate.QueryArtists().All(ctx)

	if len(companyartists) != 0 {
		t.Errorf("Remove artists from record company failed: Have %v artists but 0 was expected", len(companyartists))
	}
	cleanUpDatabase(t)
}
