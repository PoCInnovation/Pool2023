package tests

import (
	"SoftwareGoDay2/controller"
	"SoftwareGoDay2/ent"
	"context"
	"strings"
	"testing"
)

func TestCreateContactController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	contacts := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	expected := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546140"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	var artistCreate []*ent.Artist

	ctx := context.Background()
	ctr := controller.NewController(db)

	for _, a := range artists {
		u, err := ctr.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}
	for i, c := range contacts {
		newC, err := ctr.CreateContact(ctx, artistCreate[i].ID.String(), c.Email, c.Phone)
		if err != nil {
			t.Errorf("Contact create failed: '%v'", err)
		}
		if newC.Email != expected[i].Email {
			t.Errorf("wrong create email for contact '%v': got '%v', expected: '%v'", c.Email, newC.Email, expected[i].Email)
		}

		if newC.Phone != expected[i].Phone {
			t.Errorf("wrong create Phone for contact '%v': got '%v', expected: '%v'", c.Email, newC.Phone, expected[i].Phone)
		}
	}
	cleanUpDatabase(t)
}

func TestCreateContactErrorController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	var artistCreate []*ent.Artist

	ctx := context.Background()
	ctr := controller.NewController(db)

	for _, a := range artists {
		u, err := ctr.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}

	_, err := ctr.CreateContact(ctx, artistCreate[0].ID.String(), "", "0678546140")

	if !strings.Contains(err.Error(), "contact email is invalid") {
		t.Errorf("Failed, you didn't check if email was empty. error: %v", err)
	}

	_, err = ctr.CreateContact(ctx, artistCreate[1].ID.String(), "Florida@travel.com_test", "")

	if !strings.Contains(err.Error(), "contact phone is invalid") {
		t.Errorf("Failed, you didn't check if phone number was empty. error: %v", err)
	}
	cleanUpDatabase(t)
}

func TestUpdateContactController(t *testing.T) {
	artists := []struct {
		Name, Nationality string
	}{
		{Name: "Florida_test", Nationality: "us"},
		{Name: "Charles Aznavour_test", Nationality: "am"},
	}
	contacts := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "a"},
		{Email: "a_test", Phone: "0780156782"},
	}
	Updates := []struct {
		Email, Phone string
	}{
		{Email: "", Phone: "0678546141"},
		{Email: "Charles@Aznavour.fr_test", Phone: ""},
	}
	expected := []struct {
		Email, Phone string
	}{
		{Email: "Florida@travel.com_test", Phone: "0678546141"},
		{Email: "Charles@Aznavour.fr_test", Phone: "0780156782"},
	}
	var artistCreate []*ent.Artist

	ctx := context.Background()
	ctr := controller.NewController(db)

	for _, a := range artists {
		u, err := ctr.CreateArtist(ctx, a.Name, a.Nationality)
		artistCreate = append(artistCreate, u)
		if err != nil {
			t.Errorf("artist create failed: %v", err)
		}
	}
	for i, c := range contacts {
		_, err := ctr.CreateContact(ctx, artistCreate[i].ID.String(), c.Email, c.Phone)
		if err != nil {
			t.Errorf("Contact create failed: '%v'", err)
		}
	}

	for i, c := range Updates {
		upC, err := ctr.UpdateContact(ctx, artistCreate[i].ID.String(), c.Email, c.Phone)
		if err != nil {
			t.Errorf("Contact update failed: '%v'", err)
		}
		if upC.Email != expected[i].Email {
			t.Errorf("wrong update email for contact '%v': got '%v', expected: '%v'", c.Email, upC.Email, expected[i].Email)
		}
		if upC.Phone != expected[i].Phone {
			t.Errorf("wrong update Phone for contact '%v': got '%v', expected: '%v'", c.Email, upC.Phone, expected[i].Phone)
		}
	}
	cleanUpDatabase(t)
}

func TestUpdateContactErrorController(t *testing.T) {
	ctx := context.Background()
	ctr := controller.NewController(db)
	a, _ := ctr.CreateArtist(ctx, "Artists_test", "fr")

	_, err := ctr.UpdateContact(ctx, "f99db285-96a7-4bc5-ab9a-13430f1a14fc", "", "")
	if err == nil || !strings.Contains(err.Error(), "ent: artist not found") {
		t.Errorf("Failed, you didn't check if artist id exist. error: '%v'", err)
	}
	_, err = ctr.UpdateContact(ctx, a.ID.String(), "", "")
	if err == nil || !strings.Contains(err.Error(), "ent: contact not found") {
		t.Errorf("Failed, you didn't check if artist have any contact. error: '%v'", err)
	}
	cleanUpDatabase(t)
}
