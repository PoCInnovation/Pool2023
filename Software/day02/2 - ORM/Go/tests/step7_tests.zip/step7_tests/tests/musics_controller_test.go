package tests

import (
	"SoftwareGoDay2/controller"
	"SoftwareGoDay2/ent"
	"context"
	"strings"
	"testing"
)

func TestCreateMusicController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lala_test", Link: "lala.fr"},
		{Name: "lili_test", Link: "lili.fr"},
		{Name: "lolo_test", Link: "lolo.fr"},
	}
	expected := []struct {
		Name string
		Link string
	}{
		{Name: "lala_test", Link: "lala.fr"},
		{Name: "lili_test", Link: "lili.fr"},
		{Name: "lolo_test", Link: "lolo.fr"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)

	for i, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
		if newMusic.Name != expected[i].Name {
			t.Errorf("wrong create Name music: got '%v', expected: '%v'", newMusic.Name, expected[i].Name)
		}
		if newMusic.Link != expected[i].Link {
			t.Errorf("wrong create Link music: got '%v', expected: '%v'", newMusic.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestGetMusicController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lili_test", Link: "lili.fr"},
		{Name: "lolo_test", Link: "lolo.fr"},
		{Name: "lala_test", Link: "lala.fr"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)

	for _, music := range musics {
		_, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		if err != nil {
			t.Errorf("Create Music failed: '%v'", err)
		}
	}
	MusicList, err := ctr.GetMusic(ctx)
	if err != nil {
		t.Errorf("Get all musics failed: '%v'", err)
	}
	nb := 0
	for _, music := range MusicList {
		if strings.Contains(music.Name, "_test") {
			nb += 1
		}
	}
	if nb != len(musics) {
		t.Errorf("Get all musics failed. Get %v but expeted %v", t, len(musics))
	}
	cleanUpDatabase(t)
}

func TestGetMusicByIdController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lala_test", Link: "lala.fr"},
		{Name: "lili_test", Link: "lili.fr"},
		{Name: "lolo_test", Link: "lolo.fr"},
	}

	ctx := context.Background()
	ctr := controller.NewController(db)
	var musicCreate []*ent.Music

	for _, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		musicCreate = append(musicCreate, newMusic)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
	}
	for _, music := range musicCreate {
		GetMusic, err := ctr.GetMusicById(ctx, music.ID.String())
		if err != nil {
			t.Errorf("Get Music by id failed: '%v'", err)
		}
		if music.Name != GetMusic.Name {
			t.Errorf("Get Music by id failed for '%v'. Got '%v' but '%v' expected ", music.Name, GetMusic.Name, music.Name)
		}
	}
	cleanUpDatabase(t)
}

func TestMusicUpdateController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lolo_test", Link: "lal.fr"},
		{Name: "li_test", Link: "lil.fr"},
	}
	update := []struct {
		Name string
		Link string
	}{
		{Name: "lala_test", Link: "lala.fr"},
		{Name: "lili_test", Link: "lili.fr"},
	}
	expected := []struct {
		Name string
		Link string
	}{
		{Name: "lala_test", Link: "lala.fr"},
		{Name: "lili_test", Link: "lili.fr"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)
	var musicCreate []*ent.Music

	for _, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		musicCreate = append(musicCreate, newMusic)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
	}

	for i, u := range update {
		musicCreate[i].Name = u.Name
		updatemusic, err := ctr.UpdateMusic(ctx, musicCreate[i].ID.String(), musicCreate[i].Name, musicCreate[i].Link)
		if err != nil {
			t.Errorf("Music update failed: '%v'", err)
		}
		if updatemusic.Name != expected[i].Name {
			t.Errorf("wrong update Name Music: got '%v', expected: '%v'", updatemusic.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteMusicController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lolo_test", Link: "lal.fr"},
		{Name: "li_test", Link: "lil.fr"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)

	var musicCreate []*ent.Music

	for _, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		musicCreate = append(musicCreate, newMusic)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
	}

	for _, u := range musicCreate {
		_, err := ctr.DeleteMusic(ctx, u.ID.String())
		if err != nil {
			t.Errorf("Music delete failed: '%v'", err)
		}
		_, err = ctr.GetMusicById(ctx, u.ID.String())
		if err == nil {
			t.Errorf("Music delete failed, '%v' still exits in database", u)
		}
	}
	cleanUpDatabase(t)
}

func TestAddArtistsToMusicController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "loloas_test", Link: "lal.fr"},
		{Name: "lia_test", Link: "lil.fr"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)
	u1, _ := ctr.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := ctr.CreateArtist(ctx, "jb_test", "fr")

	for _, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
		newMusic, err = ctr.AddArtistsToMusic(ctx, newMusic.ID.String(), u1.ID.String())
		if err != nil {
			t.Errorf("Add artist to Music failed: '%v'", err)
		}
		newMusic, err = ctr.AddArtistsToMusic(ctx, newMusic.ID.String(), u2.ID.String())
		if err != nil {
			t.Errorf("Add artist to Music failed: '%v'", err)
		}
		musicArtists, _ := newMusic.QueryArtists().All(ctx)
		if len(musicArtists) != 2 {
			t.Errorf("Add artists to Music failed: Only have %v but 2 was expected", len(musicArtists))
		}
	}
	cleanUpDatabase(t)
}

func TestRemoveArtistsToMusicController(t *testing.T) {
	musics := []struct {
		Name string
		Link string
	}{
		{Name: "lolo_test", Link: "lal.fr"},
		{Name: "li_test", Link: "lil.fr"},
	}
	ctx := context.Background()
	ctr := controller.NewController(db)

	u1, _ := ctr.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := ctr.CreateArtist(ctx, "jb_test", "fr")
	var musicCreate *ent.Music

	for _, music := range musics {
		newMusic, err := ctr.CreateMusic(ctx, music.Name, music.Link)
		if err != nil {
			t.Errorf("Music create failed: '%v'", err)
		}
		newMusic, _ = ctr.AddArtistsToMusic(ctx, newMusic.ID.String(), u1.ID.String())
		newMusic, _ = ctr.AddArtistsToMusic(ctx, newMusic.ID.String(), u2.ID.String())
		musicCreate = newMusic
	}
	ctr.RemoveArtistsFromMusic(ctx, musicCreate.ID.String(), u1.ID.String())
	musicArtists, _ := musicCreate.QueryArtists().All(ctx)

	if len(musicArtists) != 1 {
		t.Errorf("Remove artists from Music failed: Have %v artists but 1 was expected", len(musicArtists))
	}
	ctr.RemoveArtistsFromMusic(ctx, musicCreate.ID.String(), u2.ID.String())
	musicArtists, _ = musicCreate.QueryArtists().All(ctx)

	if len(musicArtists) != 0 {
		t.Errorf("Remove artists from Music failed: Have %v artists but 0 was expected", len(musicArtists))
	}
	cleanUpDatabase(t)
}
