package tests

import (
	"SoftwareGoDay2/ent"
	"context"
	"testing"
)

func TestCreateRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	expected := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()

	for i, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		if newRC.Name != expected[i].Name {
			t.Errorf("wrong create Name Record Company: got '%v', expected: '%v'", newRC.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestGetRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}
	RecordCompaniesList, err := db.GetRecordCompanies(ctx)
	if err != nil {
		t.Errorf("Get all record company failed: '%v'", err)
	}
	for i, rc := range RecordCompaniesList {
		if rc.ID == recordCompanyCreate[i].ID && rc.Name != recordCompanyCreate[i].Name {
			t.Errorf("Get all record company failed. %v", err)
		}
	}
	cleanUpDatabase(t)
}

func TestGetRecordCompanyById(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}

	ctx := context.Background()
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}
	for _, rc := range recordCompanyCreate {
		getRC, err := db.GetRecordCompanyByID(ctx, rc.ID)
		if err != nil {
			t.Errorf("Get Record Company by id failed: '%v'", err)
		}
		if rc.Name != getRC.Name {
			t.Errorf("Get record company by id failed for '%v'. Got '%v' but '%v' expected ", rc.Name, getRC.Name, rc.Name)
		}
	}
	cleanUpDatabase(t)
}

func TestRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "aa"},
	}
	update := []struct {
		Name string
	}{
		{Name: "Epison_test_new"},
		{Name: "Abbey Road Studios_test"},
	}
	expected := []struct {
		Name string
	}{
		{Name: "Epison_test_new"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}

	for i, u := range update {
		recordCompanyCreate[i].Name = u.Name
		updateRC, err := db.UpdateRecordCompany(ctx, recordCompanyCreate[i])
		if err != nil {
			t.Errorf("Record Company update failed: '%v'", err)
		}
		if updateRC.Name != expected[i].Name {
			t.Errorf("wrong update Name Record Company: got '%v', expected: '%v'", updateRC.Name, expected[i].Name)
		}
	}
	cleanUpDatabase(t)
}

func TestDeleteRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "aa"},
	}
	ctx := context.Background()
	var recordCompanyCreate []*ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		recordCompanyCreate = append(recordCompanyCreate, newRC)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
	}

	for _, u := range recordCompanyCreate {
		_, err := db.DeleteRecordCompany(ctx, u.ID)
		if err != nil {
			t.Errorf("Record Company delete failed: '%v'", err)
		}
		_, err = db.GetRecordCompanyByID(ctx, u.ID)
		if err == nil {
			t.Errorf("Record Company delete failed, '%v' still exits in database", u)
		}
	}
	cleanUpDatabase(t)
}

func TestAddArtistToRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	u1, _ := db.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := db.CreateArtist(ctx, "jb_test", "fr")

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		newRC, err = db.AddArtistToRecordCompany(ctx, newRC.ID, u1.ID)
		if err != nil {
			t.Errorf("Add artist to record company failed: '%v'", err)
		}
		newRC, err = db.AddArtistToRecordCompany(ctx, newRC.ID, u2.ID)
		if err != nil {
			t.Errorf("Add artist to record company failed: '%v'", err)
		}
		companyartists, _ := newRC.QueryArtists().All(ctx)
		if len(companyartists) != 2 {
			t.Errorf("Add artists to record company failed: Only have %v but 2 was expected", len(companyartists))
		}
	}
	cleanUpDatabase(t)
}

func TestRemoveArtistToRecordCompany(t *testing.T) {
	record_company := []struct {
		Name string
	}{
		{Name: "Epison_test"},
		{Name: "Abbey Road Studios_test"},
	}
	ctx := context.Background()
	u1, _ := db.CreateArtist(ctx, "Florida_test", "us")
	u2, _ := db.CreateArtist(ctx, "jb_test", "fr")
	var recordCompanyCreate *ent.RecordCompany

	for _, rc := range record_company {
		newRC, err := db.CreateRecordCompany(ctx, rc.Name)
		if err != nil {
			t.Errorf("Record Company create failed: '%v'", err)
		}
		newRC, _ = db.AddArtistToRecordCompany(ctx, newRC.ID, u1.ID)
		newRC, _ = db.AddArtistToRecordCompany(ctx, newRC.ID, u2.ID)
		recordCompanyCreate = newRC
	}
	db.RemoveArtistFromRecordCompany(ctx, recordCompanyCreate.ID, u1.ID)
	companyartists, _ := recordCompanyCreate.QueryArtists().All(ctx)

	if len(companyartists) != 1 {
		t.Errorf("Remove artists from record company failed: Have %v artists but 1 was expected", len(companyartists))
	}
	db.RemoveArtistFromRecordCompany(ctx, recordCompanyCreate.ID, u2.ID)
	companyartists, _ = recordCompanyCreate.QueryArtists().All(ctx)

	if len(companyartists) != 0 {
		t.Errorf("Remove artists from record company failed: Have %v artists but 0 was expected", len(companyartists))
	}
	cleanUpDatabase(t)
}
