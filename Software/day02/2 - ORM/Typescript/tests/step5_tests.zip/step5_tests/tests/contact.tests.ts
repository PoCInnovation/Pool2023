import prisma from '../src/client';
import { createArtist, getArtist } from '../src/models/artist';
import { createContact, deleteContact, updateContact } from '../src/models/contact';

afterEach(() => prisma.artist.deleteMany({ where: { name: { startsWith: 'tests_' } } }));

describe('Contact model tests', () => {
  test('Add a new Contact', async () => {
    const artist = await createArtist({ name: 'tests_Reza', nationality: 'French' });
    const contact = await createContact(artist.id, 'email', 'phone', 'spotify', 'youtube');

    expect(contact).toStrictEqual({
      id: contact.id,
      email: 'email',
      phone: 'phone',
      spotify: 'spotify',
      youtube: 'youtube',
      artistId: artist.id,
    });
  });

  test('Update a contact', async () => {
    const artist = await createArtist({ name: 'tests_Adrien', nationality: 'Brazilian' });
    const contact = await createContact(artist.id, 'email', 'phone', 'spotify', 'youtube');
    const updatedContact = await updateContact(artist.id, { email: 'elpresidente@poc.fr', youtube: 'Adrien_ASMR' });

    expect(updatedContact).toStrictEqual({
      ...contact,
      email: 'elpresidente@poc.fr',
      youtube: 'Adrien_ASMR',
    });
  });

  test('Get a Contact from Artist', async () => {
    const artist = await createArtist({ name: 'tests_Yoel', nationality: 'Italian' });
    const contact = await createContact(artist.id, 'email', 'phone', 'spotify', 'youtube');
    const retrievedArtist = await getArtist(artist.id);

    expect(retrievedArtist).toStrictEqual({
      ...artist,
      contact: expect.objectContaining(contact),
    });
  });

  test('Delete a Contact', async () => {
    const artist = await createArtist({ name: 'tests_Alexandre', nationality: 'American' });
    const contact = await createContact(artist.id, 'email', 'phone', 'spotify', 'youtube');

    const deletedContact = await deleteContact(artist.id);
    const retrievedArtist = await getArtist(artist.id);

    expect(deletedContact).toStrictEqual(contact);
    expect(retrievedArtist).toMatchObject({ contact: null });
  });
});
