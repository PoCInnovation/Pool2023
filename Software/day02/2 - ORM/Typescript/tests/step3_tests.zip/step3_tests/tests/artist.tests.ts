import prisma from '../src/client';
import { createArtist, deleteArtist, getArtist, getArtists, updateArtist } from '../src/models/artist';

afterEach(() => prisma.artist.deleteMany({ where: { name: { startsWith: 'tests_' } } }));

describe('Artist model tests', () => {
  test('Add a new Artist', async () => {
    const artist = await createArtist({ name: 'tests_Reza', nationality: 'French' });

    expect(artist).toStrictEqual({
      id: artist.id,
      name: 'tests_Reza',
      nationality: 'French',
    });
  });

  test('Get a specific Artist', async () => {
    const artist = await createArtist({ name: 'tests_Adrien', nationality: 'Brazilian' });
    const retrievedArtist = await getArtist(artist.id);

    expect(retrievedArtist).toStrictEqual({
      id: artist.id,
      name: 'tests_Adrien',
      nationality: 'Brazilian',
    });
  });

  test('Get all the Artists', async () => {
    await createArtist({ name: 'tests_Reza', nationality: 'French' });
    await createArtist({ name: 'tests_Adrien', nationality: 'Brazilian' });

    const artists = await getArtists();

    expect(artists).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          name: 'tests_Reza',
          nationality: 'French',
        }),
        expect.objectContaining({
          name: 'tests_Adrien',
          nationality: 'Brazilian',
        }),
      ]),
    );
  });

  test('Update an Artist', async () => {
    const artist = await createArtist({ name: 'tests_Yoel', nationality: 'Italian' });
    const updatedArtist = await updateArtist(artist.id, { name: 'tests_Toni' });

    expect(updatedArtist).toStrictEqual({
      id: artist.id,
      name: 'tests_Toni',
      nationality: 'Italian',
    });
  });

  test('Delete an Artist', async () => {
    const artist = await createArtist({ name: 'tests_Alexandre', nationality: 'American' });

    const deletedArtist = await deleteArtist(artist.id);
    const retrievedArtist = await getArtist(artist.id);

    expect(deletedArtist).toStrictEqual({
      id: artist.id,
      name: 'tests_Alexandre',
      nationality: 'American',
    });

    expect(retrievedArtist).toBe(null);
  });
});
