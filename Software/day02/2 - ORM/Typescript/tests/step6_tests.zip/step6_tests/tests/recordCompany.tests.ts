import prisma from '../src/client';
import { createArtist, getArtist } from '../src/models/artist';
import {
  addArtistToRecordCompany,
  createRecordCompany,
  deleteRecordCompany,
  getRecordCompanies,
  getRecordCompany,
  removeArtistFromRecordCompany,
  updateRecordCompany,
} from '../src/models/recordCompany';

afterEach(() => prisma.recordCompany.deleteMany({ where: { name: { startsWith: 'tests_' } } }));

describe('RecordCompany model tests', () => {
  test('Add a new RecordCompany', async () => {
    const recordCompany = await createRecordCompany({ name: 'tests_Warner Music Group' });

    expect(recordCompany).toStrictEqual({
      id: recordCompany.id,
      name: 'tests_Warner Music Group',
    });
  });

  test('Get a RecordCompany', async () => {
    const recordCompany = await createRecordCompany({ name: 'tests_Warner Music Group' });
    const retrievedRecordCompany = await getRecordCompany(recordCompany.id);

    expect(retrievedRecordCompany).toStrictEqual(recordCompany);
  });

  test('Get the RecordCompanies', async () => {
    await createRecordCompany({ name: 'tests_Warner Music Group' });
    await createRecordCompany({ name: 'tests_Sony Music' });

    const recordCompanies = await getRecordCompanies();

    expect(recordCompanies).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          name: 'tests_Warner Music Group',
        }),
        expect.objectContaining({
          name: 'tests_Sony Music',
        }),
      ]),
    );
  });

  test('Update a RecordCompany', async () => {
    const recordCompany = await createRecordCompany({ name: 'tests_Warner Music Group' });

    const updated = await updateRecordCompany(recordCompany.id, { name: 'tests_PoC Music' });

    expect(updated).toStrictEqual({
      id: recordCompany.id,
      name: 'tests_PoC Music',
    });
  });

  test('Delete a RecordCompany', async () => {
    const recordCompany = await createRecordCompany({ name: 'tests_PoC Music' });
    const deleted = await deleteRecordCompany(recordCompany.id);
    const retrieved = await getRecordCompany(recordCompany.id);

    expect(deleted).toStrictEqual(recordCompany);
    expect(retrieved).toBe(null);
  });

  test('Add an Artist to a RecordCompany', async () => {
    const artist = await createArtist({ name: 'tests_Reza', nationality: 'French' });
    const recordCompany = await createRecordCompany({ name: 'tests_Warner Music Group' });

    await addArtistToRecordCompany(artist.id, recordCompany.id);
    const linkedArtist = await getArtist(artist.id);

    expect(linkedArtist).toStrictEqual({
      ...artist,
      recordCompanyId: recordCompany.id,
    });
  });

  test('Remove an Artist from a RecordCompany', async () => {
    const artist = await createArtist({ name: 'tests_Reza', nationality: 'French' });
    const recordCompany = await createRecordCompany({ name: 'tests_Warner Music Group' });

    await addArtistToRecordCompany(artist.id, recordCompany.id);
    await removeArtistFromRecordCompany(artist.id, recordCompany.id);

    const unlinkedArtist = await getArtist(artist.id);
    const unlinkedRecordCompany = await getRecordCompany(recordCompany.id);

    expect(unlinkedArtist).toStrictEqual(artist);
    expect(unlinkedRecordCompany).toStrictEqual(recordCompany);
  });
});
