import prisma from '../src/client';
import { createMusic, deleteMusic, getMusic, getMusics, updateMusic } from '../src/models/music';

afterEach(() => prisma.music.deleteMany({ where: { name: { startsWith: 'tests_' } } }));

describe('Music model tests', () => {
  test('Add a new Music', async () => {
    const music = await createMusic({
      name: 'tests_Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });

    expect(music).toStrictEqual({
      id: music.id,
      name: 'tests_Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });
  });

  test('Get a Music', async () => {
    const music = await createMusic({
      name: 'tests_Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });
    const retrievedMusic = await getMusic(music.id);

    expect(retrievedMusic).toStrictEqual(music);
  });

  test('Get the Musics', async () => {
    await createMusic({ name: 'tests_Never Gonna Give You Up', link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' });
    await createMusic({ name: 'tests_Baby Shark', link: 'https://www.youtube.com/watch?v=j8z7UjET1Is' });

    const musics = await getMusics();

    expect(musics).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          name: 'tests_Never Gonna Give You Up',
          link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        }),
        expect.objectContaining({
          name: 'tests_Baby Shark',
          link: 'https://www.youtube.com/watch?v=j8z7UjET1Is',
        }),
      ]),
    );
  });

  test('Update a Music', async () => {
    const music = await createMusic({
      name: 'tests_Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });

    const updated = await updateMusic(music.id, { name: 'tests_PoC Music' });

    expect(updated).toStrictEqual({
      id: music.id,
      name: 'tests_PoC Music',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });
  });

  test('Delete a Music', async () => {
    const music = await createMusic({
      name: 'tests_Never Gonna Give You Up',
      link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    });
    const deleted = await deleteMusic(music.id);
    const retrieved = await getMusic(music.id);

    expect(deleted).toStrictEqual(music);
    expect(retrieved).toBe(null);
  });
});
