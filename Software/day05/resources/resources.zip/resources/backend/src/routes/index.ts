import { Router } from 'express';

import authMiddleware from '../middlewares/auth';

import ArtistRouter from './artist';
import AuthRouter from './auth';
import HealthRouter from './health';
import UserRouter from './user';

const router = Router();

router.use('/health', HealthRouter);
router.use('/auth', AuthRouter);
router.use('/user', authMiddleware(), UserRouter);
router.use('/artist', authMiddleware(), ArtistRouter);

export default router;
