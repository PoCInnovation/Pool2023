import axios from 'axios';
import { HOST, PORT } from '../src/config';

axios.defaults.baseURL = `http://${HOST}:${PORT}`;
axios.defaults.validateStatus = () => true;

export default axios;

export type BaseTest = {
  name: string;
  expectedStatus: number;
  expectedResponse: string;
};
