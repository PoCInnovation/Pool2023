import { StatusCodes } from 'http-status-codes';
import axios, { BaseTest } from './config';

describe('Palindrome tests', () => {
  type SingleResponse = {
    input: string;
    result: boolean;
  };
  type PalindromeTest = Omit<BaseTest, 'expectedResponse'> & {
    body: string[] | unknown;
    expectedResponse: SingleResponse[] | null;
  };
  const cases: PalindromeTest[] = [
    {
      name: 'Simple palindrome',
      body: ['kayak'],
      expectedStatus: StatusCodes.OK,
      expectedResponse: [{ input: 'kayak', result: true }],
    },
    {
      name: 'No palindrome',
      body: ['PoC'],
      expectedStatus: StatusCodes.OK,
      expectedResponse: [{ input: 'PoC', result: false }],
    },
    {
      name: 'Mixed inputs',
      body: ['Typescript', 'level'],
      expectedStatus: StatusCodes.OK,
      expectedResponse: [
        { input: 'Typescript', result: false },
        { input: 'level', result: true },
      ],
    },
    {
      name: 'No input',
      body: [],
      expectedStatus: StatusCodes.OK,
      expectedResponse: [],
    },
    {
      name: 'No body',
      body: null,
      expectedStatus: StatusCodes.BAD_REQUEST,
      expectedResponse: null,
    },
    {
      name: 'Wrong body (numbers)',
      body: [1, 2, 3, 4],
      expectedStatus: StatusCodes.BAD_REQUEST,
      expectedResponse: null,
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios({ method: 'POST', url: '/are-these-palindromes', data: test.body });
    expect(res.status).toEqual(test.expectedStatus);
    if (test.expectedResponse !== null) {
      expect(res.data).toEqual(test.expectedResponse);
    }
  });
});
