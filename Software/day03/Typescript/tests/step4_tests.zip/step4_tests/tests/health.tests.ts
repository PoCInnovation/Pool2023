import { StatusCodes } from 'http-status-codes';
import axios from './config';

describe('Health test', () => {
  test('Make a simple request', async () => {
    const res = await axios.get('/health');
    expect(res.status).toEqual(StatusCodes.OK);
  });
});
