import { StatusCodes } from 'http-status-codes';
import { HELLO_MESSAGE } from '../src/config';
import axios from './config';

describe('Hello test', () => {
  test('Make a simple request', async () => {
    const res = await axios.get('/hello');
    expect(res.status).toEqual(StatusCodes.OK);
    expect(res.data).toEqual(HELLO_MESSAGE);
  });
});
