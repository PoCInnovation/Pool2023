import axios, { BaseTest } from './config';

describe('Repeat my query tests', () => {
  type QueryTest = BaseTest & {
    query: string;
  };
  const cases: QueryTest[] = [
    {
      name: 'Simple message',
      query: '?message=SoftwarePoolPoC2023',
      expectedStatus: 200,
      expectedResponse: 'SoftwarePoolPoC2023',
    },
    {
      name: 'Query but no message',
      query: '?random=SoftwarePoolPoC2023',
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
    {
      name: 'No query',
      query: '',
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.get(`/repeat-my-query${test.query}`);
    expect(res.status).toEqual(test.expectedStatus);
    expect(res.data).toEqual(test.expectedResponse);
  });
});

describe('Repeat my param tests', () => {
  type ParamTest = Omit<BaseTest, 'expectedResponse'> & {
    param: string;
    expectedResponse?: string;
  };
  const cases: ParamTest[] = [
    {
      name: 'Simple param',
      param: 'SoftwarePoolPoC2023',
      expectedStatus: 200,
      expectedResponse: 'SoftwarePoolPoC2023',
    },
    {
      name: 'No param',
      param: '',
      expectedStatus: 404,
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.get(`/repeat-my-param/${test.param}`);
    expect(res.status).toEqual(test.expectedStatus);
    if (test.expectedResponse) {
      expect(res.data).toEqual(test.expectedResponse);
    }
  });
});

describe('Repeat my body tests', () => {
  type BodyTest = BaseTest & {
    body: Record<string, unknown>;
  };
  const cases: BodyTest[] = [
    {
      name: 'Simple body',
      body: { message: 'SoftwarePoolPoC2023' },
      expectedStatus: 200,
      expectedResponse: 'SoftwarePoolPoC2023',
    },
    {
      name: 'Body but no message',
      body: { random: 'SoftwarePoolPoC2023' },
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
    {
      name: 'Empty body',
      body: {},
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.post('/repeat-my-body', test.body);
    expect(res.status).toEqual(test.expectedStatus);
    expect(res.data).toEqual(test.expectedResponse);
  });
});

describe('Repeat my header tests', () => {
  type HeaderTest = BaseTest & {
    headers: Record<string, string>;
  };
  const cases: HeaderTest[] = [
    {
      name: 'Simple header',
      headers: { 'X-Message': 'SoftwarePoolPoC2023' },
      expectedStatus: 200,
      expectedResponse: 'SoftwarePoolPoC2023',
    },
    {
      name: 'Header but no message',
      headers: { random: 'SoftwarePoolPoC2023' },
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
    {
      name: 'Empty headers',
      headers: {},
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.get('/repeat-my-header', { headers: test.headers });
    expect(res.status).toEqual(test.expectedStatus);
    expect(res.data).toEqual(test.expectedResponse);
  });
});

describe('Repeat my cookie tests', () => {
  type CookieTest = BaseTest & {
    cookie: string;
  };
  const cases: CookieTest[] = [
    {
      name: 'Simple cookie',
      cookie: 'message=SoftwarePoolPoC2023;',
      expectedStatus: 200,
      expectedResponse: 'SoftwarePoolPoC2023',
    },
    {
      name: 'Cookie but no message',
      cookie: 'random=SoftwarePoolPoC2023;',
      expectedStatus: 401,
      expectedResponse: 'Bad Request',
    },
    {
      name: 'Empty headers',
      cookie: '',
      expectedStatus: 400,
      expectedResponse: 'Bad Request',
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.get('/repeat-my-cookie', { headers: { Cookie: test.cookie } });
    expect(res.status).toEqual(test.expectedStatus);
    expect(res.data).toEqual(test.expectedResponse);
  });
});
