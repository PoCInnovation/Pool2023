import axios from 'axios';

axios.defaults.baseURL = 'http://localhost:8080';
axios.defaults.validateStatus = () => true;

export default axios;
