import { StatusCodes } from 'http-status-codes';
import type { User } from '../src/utils';
import axios, { BaseTest } from './config';

type AuthResponse = {
  accessToken: string;
  user: User;
  message: string;
};

describe('JWT Register tests', () => {
  type RegisterTest = Omit<BaseTest, 'expectedResponse'> & {
    body: User;
    expectedResponse: AuthResponse | string;
  };
  const cases: RegisterTest[] = [
    {
      name: 'Simple register',
      body: { email: 'test-register@poc-innovation.fr', password: 'test' },
      expectedStatus: StatusCodes.CREATED,
      expectedResponse: {
        accessToken: '',
        user: { email: 'test-register@poc-innovation.fr', password: 'test' },
        message: 'User successfully created',
      },
    },
    {
      name: 'Register with existing user',
      body: { email: 'test-register@poc-innovation.fr', password: 'test' },
      expectedStatus: StatusCodes.FORBIDDEN,
      expectedResponse: 'User already exists',
    },
  ];
  test.each(cases)('$name', async (test) => {
    const res = await axios.post('/jwt/register', test.body);
    expect(res.status).toEqual(test.expectedStatus);
    if (typeof test.expectedResponse === 'string') {
      expect(res.data).toEqual(test.expectedResponse);
    } else {
      expect(res.data?.user.email).toEqual(test.expectedResponse.user.email);
      expect(res.data?.message).toEqual(test.expectedResponse.message);
    }
  });
});

describe('JWT Login tests', () => {
  type LoginTest = Omit<BaseTest, 'expectedResponse'> & {
    body: User;
    shouldRegister: boolean;
    expectedResponse: AuthResponse | string;
  };
  const cases: LoginTest[] = [
    {
      name: 'Simple login after register',
      body: { email: 'test-login@poc-innovation.fr', password: 'test' },
      shouldRegister: true,
      expectedStatus: StatusCodes.OK,
      expectedResponse: {
        accessToken: '',
        user: { email: 'test-login@poc-innovation.fr', password: 'test' },
        message: 'Successful login',
      },
    },
    {
      name: 'Wrong password',
      body: { email: 'test-login@poc-innovation.fr', password: 'wrong' },
      shouldRegister: false,
      expectedStatus: StatusCodes.NOT_FOUND,
      expectedResponse: 'Wrong password',
    },
    {
      name: 'User not found',
      body: { email: 'unknown-login@poc-innovation.fr', password: 'test' },
      shouldRegister: false,
      expectedStatus: StatusCodes.NOT_FOUND,
      expectedResponse: 'Unknown user',
    },
  ];
  test.each(cases)('$name', async (test) => {
    if (test.shouldRegister) {
      await axios.post('/jwt/register', test.body);
    }
    const res = await axios.post('/jwt/login', test.body);
    expect(res.status).toEqual(test.expectedStatus);
    if (typeof test.expectedResponse === 'string') {
      expect(res.data).toEqual(test.expectedResponse);
    } else {
      expect(res.data?.user.email).toEqual(test.expectedResponse.user.email);
      expect(res.data?.message).toEqual(test.expectedResponse.message);
    }
  });
});

describe('JWT Me tests', () => {
  type MeTest = Omit<BaseTest, 'expectedResponse'> & {
    userToRegister?: User;
    token?: string;
    expectedResponse: Omit<AuthResponse, 'accessToken'> | string;
  };
  const cases: MeTest[] = [
    {
      name: 'Simple me after register',
      userToRegister: { email: 'test-me@poc-innovation.fr', password: 'test' },
      expectedStatus: StatusCodes.OK,
      expectedResponse: {
        user: { email: 'test-me@poc-innovation.fr', password: 'test' },
        message: 'User found',
      },
    },
  ];
  test.each(cases)('$name', async (test) => {
    let accessToken = test.token;
    if (test.userToRegister) {
      accessToken = await (await axios.post('/jwt/register', test.userToRegister)).data?.accessToken;
    }
    const res = await axios.get('/jwt/me', { headers: { Authorization: `Bearer ${accessToken}` } });
    expect(res.status).toEqual(test.expectedStatus);
    if (typeof test.expectedResponse === 'string') {
      expect(res.data).toEqual(test.expectedResponse);
    } else {
      expect(res.data?.user.email).toEqual(test.expectedResponse.user.email);
      expect(res.data?.message).toEqual(test.expectedResponse.message);
    }
  });
});
